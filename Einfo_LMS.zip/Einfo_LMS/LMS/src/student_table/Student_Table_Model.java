package student_table;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;


import common.DBConnection_LMS_Portal;
import common_use_bean.Student_Use_Bean;



public class Student_Table_Model {
	public int insert_student(Student_Use_Bean obj_Student_Use_Bean){
		Connection connection=null;
		DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
		connection=obj_DBConnection_SMS_Portal.getConnection();
		PreparedStatement ps=null;
		int flag=0;
		
		
		TimeZone.setDefault(TimeZone.getTimeZone("Asia/Qatar"));
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
		 
		  Date today4 = new Date();
		  String date4 = format.format(today4);
	try { 
		
		String query="insert into employee (" +
				"empId," +
				"Name," +
				"Department," +
				"Status," +
				"Contact," +
				"email_id) values(?,?,?,?,?,?);";
			ps=connection.prepareStatement(query);
			//Sequence_Student_Id obj_Sequence_Student_Id=new Sequence_Student_Id();
			ps.setString(1,obj_Student_Use_Bean.getStudent_id());
			ps.setString(2,obj_Student_Use_Bean.getStudent_name());
			ps.setString(3,obj_Student_Use_Bean.getDepartment());
			ps.setInt(4,obj_Student_Use_Bean.getStatus());
			ps.setLong(5,obj_Student_Use_Bean.getContact());
			ps.setString(6,obj_Student_Use_Bean.getStudent_email());
			
			    System.out.println(ps);
			    System.out.println(obj_Student_Use_Bean.getDepartment());
			    
			    
			 flag=ps.executeUpdate();
			 
			 
		
		
	 }catch(Exception e){
		e.printStackTrace();
	}finally{
		if(connection!=null){
			try {
					connection.close();
				}
			 	catch (Exception e2) {
				// TODO: handle exception
			 	}
		}
		if(ps!=null){
			try {
				
				ps.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
	
}
	
	return flag;

	}	
	
	
	
	public int edit_student(Student_Use_Bean obj_Student_Use_Bean){
		Connection connection=null;
		DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
		connection=obj_DBConnection_SMS_Portal.getConnection();
		PreparedStatement ps=null;
		int flag=0;
		
		
		
	try { 
		
		String query="update student_table set " +
				"student_name=?," +
				"grade=?," +
				"profile=?," +
				"section=?," +
				"admission_no=?," +
				"status=? where student_id=?";
			ps=connection.prepareStatement(query);
			ps.setString(1,obj_Student_Use_Bean.getStudent_name());
			ps.setString(2,obj_Student_Use_Bean.getGrade());
			ps.setString(3,obj_Student_Use_Bean.getProfile());
			ps.setString(4,obj_Student_Use_Bean.getSection());
			ps.setString(5,obj_Student_Use_Bean.getAdmission_no());
			ps.setInt(6,obj_Student_Use_Bean.getStatus());
			ps.setString(7,obj_Student_Use_Bean.getStudent_id());
			
			    System.out.println(ps);
			    
			    
			 flag=ps.executeUpdate();
			 
			 query="update issue_book set " +
				"admission_no=?,student_name=? where student_id=?";
				ps=connection.prepareStatement(query);
				
				ps.setString(1,obj_Student_Use_Bean.getAdmission_no());
				ps.setString(2, obj_Student_Use_Bean.getStudent_name());
				ps.setString(3, obj_Student_Use_Bean.getStudent_id());
					
				ps.executeUpdate();
			 
		
		
	 }catch(Exception e){
		e.printStackTrace();
	}finally{
		if(connection!=null){
			try {
					connection.close();
				}
			 	catch (Exception e2) {
				// TODO: handle exception
			 	}
		}
		if(ps!=null){
			try {
				
				ps.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
	
}
	
	return flag;

	}	
	
	
	
	
	
	
	
	public List<Student_Use_Bean> get_all_recently_added_students(){
		Connection connection=null;
		DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
		connection=obj_DBConnection_SMS_Portal.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<Student_Use_Bean> list=new ArrayList<Student_Use_Bean>();
	try { 
		
		String query="select * from student_table order by added_on desc limit 10";
		ps=connection.prepareStatement(query);
		
		
		System.out.println(ps);
		rs=ps.executeQuery();
		
		
		while(rs.next()){
			Student_Use_Bean obj_Student_Use_Bean=new Student_Use_Bean();
			obj_Student_Use_Bean.setAdmission_no(rs.getString("admission_no"));
			obj_Student_Use_Bean.setStudent_id(rs.getString("student_id"));
			obj_Student_Use_Bean.setStudent_name(rs.getString("student_name"));
			list.add(obj_Student_Use_Bean);
		}
		
	 }catch(Exception e){
		e.printStackTrace();
	}finally{
		if(connection!=null){
			try {
					connection.close();
				}
			 	catch (Exception e2) {
				// TODO: handle exception
			 	}
		}
		if(ps!=null){
			try {
				
				ps.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
	
}
	
	return list;

	}	
	
	
	
	public List<Student_Use_Bean> search_result_student(String search){
		Connection connection=null;
		DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
		connection=obj_DBConnection_SMS_Portal.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<Student_Use_Bean> list=new ArrayList<Student_Use_Bean>();
	try { 
		
		String query="select employee.empId as ID, employee.Name as Name,employee.email_id as email from employee "
				+ "where "
				+ "employee.Name like ? or "
				+ "employee.email_id like ? or "
				+ "employee.empId like ? "
				+ "order by employee.Name desc limit 100;";
		ps=connection.prepareStatement(query);
		ps.setString(1, "%"+search+"%");
		ps.setString(2, "%"+search+"%");
		ps.setString(3, "%"+search+"%");
		
		System.out.println(ps);
		rs=ps.executeQuery();
		
		
		while(rs.next()){
			Student_Use_Bean obj_Student_Use_Bean=new Student_Use_Bean();
			obj_Student_Use_Bean.setStudent_id(rs.getString("ID"));
			obj_Student_Use_Bean.setStudent_name(rs.getString("Name"));
			obj_Student_Use_Bean.setStudent_email(rs.getString("email"));
			list.add(obj_Student_Use_Bean);
		}
		
	 }catch(Exception e){
		e.printStackTrace();
	}finally{
		if(connection!=null){
			try {
					connection.close();
				}
			 	catch (Exception e2) {
				// TODO: handle exception
			 	}
		}
		if(ps!=null){
			try {
				
				ps.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
	
}
	
	return list;

	}	
	
	
	public Student_Use_Bean get_complete_details_student(String student_id){
		Connection connection=null;
		DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
		connection=obj_DBConnection_SMS_Portal.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		Student_Use_Bean obj_Student_Use_Bean=new Student_Use_Bean();
	try { 
		
		String query="select * from employee where Id=?";
		ps=connection.prepareStatement(query);
		ps.setString(1, student_id);
		
		System.out.println(ps);
		rs=ps.executeQuery();
		
		
		if(rs.next()){
			obj_Student_Use_Bean.setStudent_id(rs.getString("empid"));
			obj_Student_Use_Bean.setStudent_name(rs.getString("Name"));
			obj_Student_Use_Bean.setDepartment(rs.getString("Department"));
			obj_Student_Use_Bean.setStatus(rs.getInt("status"));
			obj_Student_Use_Bean.setContact((rs.getLong("Contact")));
			obj_Student_Use_Bean.setStudent_email((rs.getString("email_id")));
		}

	 }catch(Exception e){
		e.printStackTrace();
	}finally{
		if(connection!=null){
			try {
					connection.close();
				}
			 	catch (Exception e2) {
				// TODO: handle exception
			 	}
		}
		if(ps!=null){
			try {
				
				ps.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
		if(rs!=null){
			try {
				
				rs.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
	
}
	
	return obj_Student_Use_Bean;

	}	
	
	
	
	public List<Student_Use_Bean> get_all_students(int lim){
		Connection connection=null;
		DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
		connection=obj_DBConnection_SMS_Portal.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<Student_Use_Bean> list=new ArrayList<Student_Use_Bean>();
	try { 
		
		String query="select * from employee order by Name limit "+(lim*100)+",100";
		ps=connection.prepareStatement(query);

		System.out.println(ps);
		rs=ps.executeQuery();
		
		
		while(rs.next()){
			Student_Use_Bean obj_Student_Use_Bean=new Student_Use_Bean();
			obj_Student_Use_Bean.setStudent_id(rs.getString("empId"));
			obj_Student_Use_Bean.setStudent_name(rs.getString("Name"));
			obj_Student_Use_Bean.setDepartment((rs.getString("Department")));
			obj_Student_Use_Bean.setContact((rs.getLong("Contact")));
			obj_Student_Use_Bean.setStudent_email(rs.getString("email_id"));
			obj_Student_Use_Bean.setStatus(rs.getInt("status"));
			list.add(obj_Student_Use_Bean);
		}
		
	 }catch(Exception e){
		e.printStackTrace();
	}finally{
		if(connection!=null){
			try {
					connection.close();
				}
			 	catch (Exception e2) {
				// TODO: handle exception
			 	}
		}
		if(ps!=null){
			try {
				
				ps.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
	
}
	
	return list;

	}	
	
	
	

}
