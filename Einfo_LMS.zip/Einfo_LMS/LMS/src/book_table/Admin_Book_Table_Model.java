package book_table;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import category_author_publisher_model.Category_Author_Publisher_Model;

import common.DBConnection_LMS_Portal;
import common_use_bean.Book_Use_Bean;
import common_use_bean.Sequence_Book_Id;
import common_use_bean.Sequence_inventry_Id;
import common_use_bean.Student_Use_Bean;
import java.net.*;



public class Admin_Book_Table_Model {
	public int insert_book(Book_Use_Bean obj_Book_Use_Bean){
		Connection connection=null;
		DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
		connection=obj_DBConnection_SMS_Portal.getConnection();
		PreparedStatement ps=null;
		int flag=0;

		TimeZone.setDefault(TimeZone.getTimeZone("Asia/Qatar"));
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");

		Date today4 = new Date();
		String date4 = format.format(today4);
		ResultSet rs=null;
	    try { 
			  Category_Author_Publisher_Model obj_Category_Table_Model = new Category_Author_Publisher_Model();
			  obj_Category_Table_Model.insert_category(obj_Book_Use_Bean.getCategory_name(), obj_Book_Use_Bean.getState(), obj_Book_Use_Bean.getDate());
			  String querry = "insert into author (Name) values(?)";
			  ps=connection.prepareStatement(querry);
			  ps.setString(1,obj_Book_Use_Bean.getAuthor_name());
			  System.out.println(ps);
			  ps.executeUpdate();
			  querry = "select * from author";
			  ps=connection.prepareStatement(querry);
			  rs = ps.executeQuery();
			  while(rs.next()){
					obj_Book_Use_Bean.setAuthId((rs.getInt("Id")));
				}
			  querry = "select * from category";
			  ps=connection.prepareStatement(querry);
			  rs = ps.executeQuery();
			  while(rs.next()){
				  obj_Book_Use_Bean.setCatId(rs.getInt("Id"));
				}
			  querry = "insert into book (Name,CategoryId,AuthorId,Isbn_Number) values(?,?,?,?)";
			  ps=connection.prepareStatement(querry);
			  ps.setString(1,obj_Book_Use_Bean.getBook_title());
			  ps.setInt(2, obj_Book_Use_Bean.getCatId());
			  ps.setInt(3, obj_Book_Use_Bean.getAuthId());
			  ps.setString(4, obj_Book_Use_Bean.getIsbn());
			  flag=ps.executeUpdate();

			  

	 }catch(Exception e){
		e.printStackTrace();
	}finally{
		if(connection!=null){
			try {
					connection.close();
				}
			 	catch (Exception e2) {
				// TODO: handle exception
			 	}
		}
		if(ps!=null){
			try {
				
				ps.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
	
}
	
	return flag;

	}	

	public int edit_book(Book_Use_Bean obj_Book_Use_Bean){
		Connection connection=null;
		DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
		connection=obj_DBConnection_SMS_Portal.getConnection();
		PreparedStatement ps=null;
		int flag=0;
        /*
        Book Name:
        update book inner join Category on book.CategoryId=Category.Id set book.Name='BookX'
        where book.Isbn_Number='1234';

        Category Name:
        update Category inner join book on book.CategoryId=Category.Id set Category.Name='BookXCategory'
        where book.Isbn_Number='1234';

        Author Name:
        Update Author inner join book on book.AuthorId=Author.Id set Author.Name='Rajesh'
        where book.Isbn_Number='1234';
        */
		
		TimeZone.setDefault(TimeZone.getTimeZone("Asia/Qatar"));
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
		 
		  Date today4 = new Date();
		  String date4 = format.format(today4);
	try { 

		    String BookNamequery="update book inner join Category on book.CategoryId=Category.Id set " +
				"book.Name=? " +
				"where book.Isbn_Number=?;";
			ps=connection.prepareStatement(BookNamequery);
		
			ps.setString(1,obj_Book_Use_Bean.getBook_title());
			ps.setString(2,obj_Book_Use_Bean.getIsbn());
			 System.out.println(ps);
			 ps.executeUpdate();
			 
			 String CategoryNamequery="update Category inner join book on book.CategoryId=Category.Id set " +
						"Category.Name=? " +
						"where book.Isbn_Number=?;";
			 
			 ps=connection.prepareStatement(CategoryNamequery);

			 ps.setString(1,obj_Book_Use_Bean.getCategory_name());
			 ps.setString(2, obj_Book_Use_Bean.getIsbn());
			 System.out.println(ps);
			 ps.executeUpdate();

			 String AuthorNamequery="update Author inner join book on book.AuthorId=Author.Id set " +
							"Author.Name=? " +
							"where book.Isbn_Number=?;";
				 
			 ps=connection.prepareStatement(AuthorNamequery);

			 ps.setString(1,obj_Book_Use_Bean.getAuthor_name());
			 ps.setString(2, obj_Book_Use_Bean.getIsbn());
			 System.out.println(ps);
			 flag=ps.executeUpdate();
			 
			 String descriptionquery="update book set Description=? where Isbn_Number=?;";
		     ps=connection.prepareStatement(descriptionquery);

		     ps.setString(1,obj_Book_Use_Bean.getBook_Description());
		     ps.setString(2, obj_Book_Use_Bean.getIsbn());
		     System.out.println(ps);
		     flag=ps.executeUpdate();
	 }catch(Exception e){
		e.printStackTrace();
	}finally{
		if(connection!=null){
			try {
					connection.close();
				}
			 	catch (Exception e2) {
				// TODO: handle exception
			 	}
		}
		if(ps!=null){
			try {
				
				ps.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
	
}
	
	return flag;

	}	

	public List<Book_Use_Bean> get_all_recently_added_books(){
		Connection connection=null;
		DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
		connection=obj_DBConnection_SMS_Portal.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<Book_Use_Bean> list=new ArrayList<Book_Use_Bean>();
	try { 
		
		String query="select * from book order by Name desc limit 10";
		ps=connection.prepareStatement(query);
		
		
		System.out.println(ps);
		rs=ps.executeQuery();
		
		
		while(rs.next()){
			Book_Use_Bean obj_Book_Use_Bean=new Book_Use_Bean();
				obj_Book_Use_Bean.setBook_title(rs.getString("Name"));
				obj_Book_Use_Bean.setBook_sl_no(rs.getString("Id"));
			
			list.add(obj_Book_Use_Bean);
		}
		
	 }catch(Exception e){
		e.printStackTrace();
	}finally{
		if(connection!=null){
			try {
					connection.close();
				}
			 	catch (Exception e2) {
				// TODO: handle exception
			 	}
		}
		if(ps!=null){
			try {
				
				ps.close();
				}
			 catch (Exception e2) {
				// TODO: handle exception
			}
		}
	
}
	
	return list;

	}	
	
    public Book_Use_Bean get_Complete_details_of_book(String book_sl_no){
							Connection connection=null;
							DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
							connection=obj_DBConnection_SMS_Portal.getConnection();
							PreparedStatement ps=null;
							ResultSet rs=null;
							Book_Use_Bean obj_Book_Use_Bean=new Book_Use_Bean();
						try { 
							
							String query="select book.Id as Id, book.Name as Title, book.Isbn_Number as ISBN,book.Issue as Issue,book.ReturnDate as ReturnDate ,book.Description as Description, category.Name as Category" + 
									", category.status as Status, author.Name as Author  from book inner join category" + 
									" on book.CategoryId = category.Id  inner join author on book.AuthorId=author.Id" + 
									" where book.Id=?;";
							ps=connection.prepareStatement(query);

							ps.setString(1, book_sl_no);
							System.out.println(ps);
							rs=ps.executeQuery();

							while(rs.next()){
									obj_Book_Use_Bean.setBook_title(rs.getString("Title"));
									obj_Book_Use_Bean.setBookId(rs.getInt(("Id")));
									obj_Book_Use_Bean.setCategory_name(rs.getString("Category"));
									obj_Book_Use_Bean.setAuthor_name(rs.getString("Author"));
									obj_Book_Use_Bean.setIsbn(rs.getString("ISBN"));
									obj_Book_Use_Bean.setBook_Description(rs.getString("Description"));
									obj_Book_Use_Bean.setBook_IssueCount(rs.getInt("Issue"));
									obj_Book_Use_Bean.setBook_ReturnDate(rs.getString("ReturnDate"));
									System.out.println("BOOK ISSUE COUNT");
									System.out.println(obj_Book_Use_Bean.getBook_IssueCount());
							}

						 }catch(Exception e){
							e.printStackTrace();
						}finally{
							if(connection!=null){
								try {
										connection.close();
									}
								 	catch (Exception e2) {
									// TODO: handle exception
								 	}
							}
							if(ps!=null){
								try {
									
									ps.close();
									}
								 catch (Exception e2) {
									// TODO: handle exception
								}
							}
						
					}
						
						return obj_Book_Use_Bean;
					
						}	
						
	public List<Book_Use_Bean> search_result_book(String search){
							Connection connection=null;
							DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
							connection=obj_DBConnection_SMS_Portal.getConnection();
							PreparedStatement ps=null;
							ResultSet rs=null;
							List<Book_Use_Bean> list=new ArrayList<Book_Use_Bean>();
						try { 
							
							String query="select book.Id as ID, book.Name as Title,book.Isbn_Number as ISBN, book.URL as URL, book.Rating as Rating, Category.Name as Category, " +
									"Author.Name as Author from book inner join category on book.CategoryId=category.Id inner join Author " +
									"on book.AuthorId = Author.Id " +
									"where book.Name like ? or " +
									"Category.Name like ? or " +
									"Author.Name like ? or " +
									"book.Isbn_Number like ? " +
									"order by book.Name desc limit 100;";
							ps=connection.prepareStatement(query);
							ps.setString(1, "%"+search+"%");
							ps.setString(2, "%"+search+"%");
							ps.setString(3, "%"+search+"%");
							ps.setString(4, "%"+search+"%");
							
							System.out.println(ps);
							rs=ps.executeQuery();
							
							
							while(rs.next()){
								Book_Use_Bean obj_Book_Use_Bean=new Book_Use_Bean();
								obj_Book_Use_Bean.setBook_title(rs.getString("Title"));
								obj_Book_Use_Bean.setCategory_name(rs.getString("Category"));
								obj_Book_Use_Bean.setAuthor_name(rs.getString("Author"));;
								obj_Book_Use_Bean.setIsbn(rs.getString("ISBN"));
								obj_Book_Use_Bean.setBook_sl_no((rs.getString("ID")));
								obj_Book_Use_Bean.setBookUrl((rs.getString("URL")));
								obj_Book_Use_Bean.setBookRating((rs.getInt("Rating")));
								list.add(obj_Book_Use_Bean);
							}
							
						 }catch(Exception e){
							e.printStackTrace();
						}finally{
							if(connection!=null){
								try {
										connection.close();
									}
								 	catch (Exception e2) {
									// TODO: handle exception
								 	}
							}
							if(ps!=null){
								try {
									
									ps.close();
									}
								 catch (Exception e2) {
									// TODO: handle exception
								}
							}
						
					}
						
						return list;

						}	
						
    public List<Book_Use_Bean> view_all_books(int lim){
							Connection connection=null;
							DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
							connection=obj_DBConnection_SMS_Portal.getConnection();
							PreparedStatement ps=null;
							ResultSet rs=null;
							List<Book_Use_Bean> list=new ArrayList<Book_Use_Bean>();
						try { 
							
							String query="select book.Id as Id, book.URL as url, book.Name as Title, book.Rating as Rating,Isbn_Number as ISBN, Author.Name as Author from book inner join Author on book.AuthorId = Author.Id limit "+(lim*100)+",100;";
							ps=connection.prepareStatement(query);
							
							
							System.out.println(ps);
							rs=ps.executeQuery();
							
							
							while(rs.next()){
								Book_Use_Bean obj_Book_Use_Bean=new Book_Use_Bean();
								obj_Book_Use_Bean.setBook_title(rs.getString("Title"));
								obj_Book_Use_Bean.setAuthor_name(rs.getString("Author"));
								obj_Book_Use_Bean.setIsbn(rs.getString("isbn"));
								obj_Book_Use_Bean.setBookId(rs.getInt("Id"));
								obj_Book_Use_Bean.setBookUrl(rs.getString("url"));
								obj_Book_Use_Bean.setBookRating(rs.getInt("Rating"));
								list.add(obj_Book_Use_Bean);
							}
							
						 }catch(Exception e){
							e.printStackTrace();
						}finally{
							if(connection!=null){
								try {
										connection.close();
									}
								 	catch (Exception e2) {
									// TODO: handle exception
								 	}
							}
							if(ps!=null){
								try {
									
									ps.close();
									}
								 catch (Exception e2) {
									// TODO: handle exception
								}
							}
						
					}
						
						return list;

						}
											
	public int notifyAdmin(){
							Connection connection=null;
							DBConnection_LMS_Portal obj_DBConnection_SMS_Portal=new DBConnection_LMS_Portal();
							connection=obj_DBConnection_SMS_Portal.getConnection();
							PreparedStatement ps=null;
							int flag=0;
							ResultSet rs=null;
							List<Book_Use_Bean> list=new ArrayList<Book_Use_Bean>();
						try { 
							
							String query="select Name from book where Id=1;";
							ps=connection.prepareStatement(query);
							System.out.println(ps);
							rs=ps.executeQuery();

							while(rs.next()){
								Book_Use_Bean obj_Book_Use_Bean=new Book_Use_Bean();
								obj_Book_Use_Bean.setBook_title(rs.getString("Name"));
								list.add(obj_Book_Use_Bean);
								flag = 1;
							}
							
							for (Book_Use_Bean b :list)
							{
								System.out.println(b.getBook_title());
							}
							
						 }catch(Exception e){
							 flag = 0;
							e.printStackTrace();
						}finally{
							if(connection!=null){
								try {
										connection.close();
									}
								 	catch (Exception e2) {
									// TODO: handle exception
								 	}
							}
							if(ps!=null){
								try {
									
									ps.close();
									}
								 catch (Exception e2) {
									// TODO: handle exception
								}
							}
						
					}
						
						return flag;

						}
						
						
	

}
