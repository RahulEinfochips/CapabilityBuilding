package common;

public class Common_Things {

	public static String url="http://localhost:8081/LMS";
	
	   
	
	//public static String url="http://localhost:8080/LMS";
}
