package common;

public class Common_Things {

	public static String url="http://punecpu313:8082/LMS";
	
	   
	
	//public static String url="http://localhost:8080/LMS";
}
